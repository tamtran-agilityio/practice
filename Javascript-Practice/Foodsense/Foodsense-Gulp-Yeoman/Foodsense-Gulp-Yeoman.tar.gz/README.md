#Run practice on machine
  npm install
  bower install
  gulp build
  gulp serve
  Run on browser with address : localhost:9000
