#Installation
    bower install
    npm install

#Run practice to preview and watch for changes
    gulp

Run on browser with address 'localhost:9000'
